<?php
echo "Xin chào";





?>